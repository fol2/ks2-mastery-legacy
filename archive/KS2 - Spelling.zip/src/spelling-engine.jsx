// Spelling engine — reads words from KS2_SENTENCE_BANK and runs a real session.
// Uses browser SpeechSynthesis for "read aloud". Deterministic grading.

(function () {
  const ALL_WORDS = Object.keys(window.KS2_SENTENCE_BANK || {});

  // Small adaptive word list — a sensible KS2 cut
  const DEFAULT_SET = ALL_WORDS.length ? ALL_WORDS.slice(0, 60) : [
    'accident','actually','address','answer','appear','believe','bicycle',
    'breath','business','calendar','caught','century','certain','different',
    'difficult','early','enough','famous','February','favourite','forward',
    'friend','guard','heart','imagine','interest','island','knowledge',
    'library','medicine','minute','natural','naughty','ordinary','particular',
    'peculiar','potatoes','pressure','probably','promise','question','recent',
    'remember','separate','special','straight','surprise','therefore','though',
    'thought','through','various','weight','woman','women'
  ];

  function pickSentence(word) {
    const bank = (window.KS2_SENTENCE_BANK || {})[word];
    if (bank && bank.length) return bank[Math.floor(Math.random() * bank.length)];
    return `Use the word "${word}" in a sentence.`;
  }

  // Mask the target word inside the example sentence with ____
  function maskSentence(sentence, word) {
    const re = new RegExp(`\\b${word}\\b`, 'i');
    return sentence.replace(re, '_____');
  }

  // Browser read-aloud (SpeechSynthesis)
  function speak(text, rate = 1) {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = rate; u.pitch = 1; u.lang = 'en-GB';
    // prefer a UK voice if available
    const voices = window.speechSynthesis.getVoices();
    const uk = voices.find(v => /en-GB/i.test(v.lang));
    if (uk) u.voice = uk;
    window.speechSynthesis.speak(u);
  }

  // Create a session of N words, optionally filtering by "review only"
  function createSession({ length = 10, wordList = DEFAULT_SET } = {}) {
    const pool = [...wordList];
    // shuffle
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    const picks = pool.slice(0, length).map(w => {
      const sentence = pickSentence(w);
      return {
        word: w,
        sentence,
        masked: maskSentence(sentence, w),
      };
    });
    return {
      items: picks,
      index: 0,
      results: [], // { word, typed, correct, skipped }
      startedAt: Date.now(),
    };
  }

  function grade(item, typed) {
    const t = (typed || '').trim().toLowerCase();
    return {
      correct: t === item.word.toLowerCase(),
      typed: t,
    };
  }

  window.SpellingEngine = {
    DEFAULT_SET,
    createSession,
    grade,
    speak,
    pickSentence,
  };
})();
